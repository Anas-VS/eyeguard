# EyeGuard - Browser Version

Real-time eye wellness monitor running entirely in your browser.

## Live Demo

Hosted on GitHub Pages: `https://YOUR_USERNAME.github.io/eyeguard/`

## Features

- Real-time face detection using MediaPipe Face Mesh
- Eye Aspect Ratio (EAR) calculation
- PERCLOS tracking
- Blink rate & duration analysis
- Fatigue scoring (0-100)
- 4 alert types: Need Water, Sleepy, Tired, Exhausted
- Desktop notifications & sound alerts
- Screen overlay for critical alerts
- 100% private - no video leaves your browser

## How to Use

1. Open the page in your browser
2. Click "Start Monitoring"
3. Allow camera access when prompted
4. Position your face in the frame
5. Watch the metrics update in real-time

## Privacy

- All processing happens locally in your browser
- No video is sent to any server
- No data is stored
- Camera access is only used for real-time analysis

## Tech Stack

- MediaPipe Face Mesh (468 landmarks)
- Vanilla JavaScript
- HTML5 Canvas
- Web Audio API

## License

MIT
